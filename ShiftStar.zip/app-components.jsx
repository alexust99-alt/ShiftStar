/* ShiftStar — shared components. Exports to window. */

const Icon = ({ d, size = 22, fill = "none", stroke = "currentColor", sw = 2.4 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke}
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {Array.isArray(d) ? d.map((p, i) => <path key={i} d={p} />) : <path d={d} />}
  </svg>
);
const ICONS = {
  schedule: "M3 9h18M8 3v3M16 3v3M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z",
  team: ["M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2","M9 11a4 4 0 100-8 4 4 0 000 8","M22 21v-2a4 4 0 00-3-3.87","M16 3.13A4 4 0 0116 11"],
  open: ["M12 8v8M8 12h8","M12 22a10 10 0 100-20 10 10 0 000 20"],
  timeoff: ["M12 22a10 10 0 100-20 10 10 0 000 20","M12 7v5l3 2"],
  insights: ["M3 3v18h18","M7 14l3-4 3 3 4-6"],
  clock: ["M12 22a10 10 0 100-20 10 10 0 000 20","M12 7v5l3 2"],
  trash: ["M3 6h18","M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6","M10 11v6M14 11v6"],
  edit: ["M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7","M18.5 2.5a2.1 2.1 0 013 3L12 15l-4 1 1-4 9.5-9.5z"],
  check: "M5 13l4 4L19 7",
  bolt: "M13 2L4.5 13.5H11l-1 8L18.5 10H12l1-8z",
};

/* ---- Friendly star mascot (geometric star + simple face) ---- */
function StarMascot({ size = 64, color = "#FFC800", bob = false, eyes = "open" }) {
  const star = "M50 4 L62 36 L96 38 L69 60 L78 94 L50 74 L22 94 L31 60 L4 38 L38 36 Z";
  return (
    <span className={"mascot" + (bob ? " bob" : "")} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox="0 0 100 100">
        <path d={star} fill={color} stroke="rgba(0,0,0,0.12)" strokeWidth="3" strokeLinejoin="round" />
        <path d={star} fill="none" stroke="#fff" strokeWidth="2.5" strokeLinejoin="round"
              opacity="0.45" transform="scale(0.82) translate(11,9)" />
        {eyes === "open" ? (
          <>
            <circle cx="40" cy="46" r="4.4" fill="#3C3C3C" />
            <circle cx="60" cy="46" r="4.4" fill="#3C3C3C" />
            <circle cx="41.6" cy="44.4" r="1.5" fill="#fff" />
            <circle cx="61.6" cy="44.4" r="1.5" fill="#fff" />
          </>
        ) : (
          <>
            <path d="M35 46 q5 5 10 0" fill="none" stroke="#3C3C3C" strokeWidth="3" strokeLinecap="round" />
            <path d="M55 46 q5 5 10 0" fill="none" stroke="#3C3C3C" strokeWidth="3" strokeLinecap="round" />
          </>
        )}
        <path d="M40 56 q10 9 20 0" fill="none" stroke="#3C3C3C" strokeWidth="3.2" strokeLinecap="round" />
        <circle cx="32" cy="55" r="3.4" fill="#FF8A8A" opacity="0.55" />
        <circle cx="68" cy="55" r="3.4" fill="#FF8A8A" opacity="0.55" />
      </svg>
    </span>
  );
}

function Avatar({ name, color, size = "sm" }) {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return <div className={"avatar " + size} style={{ background: color }}>{initials}</div>;
}

/* ---- Sidebar ---- */
function Sidebar({ active, setActive }) {
  const nav = [
    ["schedule", "Schedule"],
    ["team", "Team"],
    ["open", "Open Shifts"],
    ["timeoff", "Time Off"],
    ["insights", "Insights"],
  ];
  return (
    <aside className="sidebar">
      <div className="brand">
        <StarMascot size={38} bob />
        <div className="brand-name">Shift<span className="star-text">Star</span></div>
      </div>
      {nav.map(([id, label]) => (
        <button key={id} className={"nav-item" + (active === id ? " active" : "")}
                onClick={() => setActive(id)}>
          <span className="ico"><Icon d={ICONS[id]} size={22} /></span>
          {label}
          {id === "open" && <span style={{ marginLeft: "auto" }}><OpenBadge /></span>}
        </button>
      ))}
      <div className="nav-spacer" />
      <div className="me-card">
        <Avatar name="Robin Vale" color="#3C3C3C" size="md" />
        <div className="meta">
          <b>Robin Vale</b><br />
          <span>Manager · Sunrise Café</span>
        </div>
      </div>
    </aside>
  );
}
// placeholder badge filled by main via context-free global setter
let _openCount = 0;
function OpenBadge() {
  const [n, setN] = React.useState(window.__openCount || 0);
  React.useEffect(() => {
    window.__setOpenBadge = setN;
    return () => { if (window.__setOpenBadge === setN) window.__setOpenBadge = null; };
  }, []);
  if (!n) return null;
  return <span style={{ background: "var(--red)", color: "#fff", fontWeight: 900, fontSize: 11,
    borderRadius: 999, padding: "2px 8px" }}>{n}</span>;
}

Object.assign(window, { Icon, ICONS, StarMascot, Avatar, Sidebar });
